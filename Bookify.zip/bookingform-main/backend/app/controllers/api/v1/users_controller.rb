# backend/app/controllers/api/v1/users_controller.rb

module Api
  module V1
    class UsersController < ApplicationController
      # You will add your actions (e.g., index, show, create, update, destroy) here later.
      # For example:
      # def index
      #   @users = User.all
      #   render json: @user
      # end
    end
  end
end
